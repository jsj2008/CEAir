
/* JavaScript content from js/google.js in folder common */


window.google = window.google || {};
google.maps = google.maps || {};
(function() {
  
  function getScript(src) {
    document.write('<' + 'script src="' + src + '"' +
                   ' type="text/javascript"><' + '/script>');
  }
  
  var modules = google.maps.modules = {};
  google.maps.__gjsload__ = function(name, text) {
    modules[name] = text;
  };
  
  google.maps.Load = function(apiLoad) {
    delete google.maps.Load;
    apiLoad([0.009999999776482582,[[["http://mt0.googleapis.com/vt?lyrs=m@207000000\u0026src=api\u0026hl=zh-CN\u0026","http://mt1.googleapis.com/vt?lyrs=m@207000000\u0026src=api\u0026hl=zh-CN\u0026"],null,null,null,null,"m@207000000"],[["http://khm0.googleapis.com/kh?v=125\u0026hl=zh-CN\u0026","http://khm1.googleapis.com/kh?v=125\u0026hl=zh-CN\u0026"],null,null,null,1,"125"],[["http://mt0.googleapis.com/vt?lyrs=h@207000000\u0026src=api\u0026hl=zh-CN\u0026","http://mt1.googleapis.com/vt?lyrs=h@207000000\u0026src=api\u0026hl=zh-CN\u0026"],null,null,"imgtp=png32\u0026",null,"h@207000000"],[["http://mt0.googleapis.com/vt?lyrs=t@130,r@207000000\u0026src=api\u0026hl=zh-CN\u0026","http://mt1.googleapis.com/vt?lyrs=t@130,r@207000000\u0026src=api\u0026hl=zh-CN\u0026"],null,null,null,null,"t@130,r@207000000"],null,null,[["http://cbk0.googleapis.com/cbk?","http://cbk1.googleapis.com/cbk?"]],[["http://khm0.googleapis.com/kh?v=71\u0026hl=zh-CN\u0026","http://khm1.googleapis.com/kh?v=71\u0026hl=zh-CN\u0026"],null,null,null,null,"71"],[["http://mt0.googleapis.com/mapslt?hl=zh-CN\u0026","http://mt1.googleapis.com/mapslt?hl=zh-CN\u0026"]],[["http://mt0.googleapis.com/mapslt/ft?hl=zh-CN\u0026","http://mt1.googleapis.com/mapslt/ft?hl=zh-CN\u0026"]],[["http://mt0.googleapis.com/vt?hl=zh-CN\u0026","http://mt1.googleapis.com/vt?hl=zh-CN\u0026"]],[["http://mt0.googleapis.com/mapslt/loom?hl=zh-CN\u0026","http://mt1.googleapis.com/mapslt/loom?hl=zh-CN\u0026"]]],["zh-CN","US",null,0,null,null,"http://maps.gstatic.com/mapfiles/","http://csi.gstatic.com","https://maps.googleapis.com","http://maps.googleapis.com"],["http://maps.gstatic.com/intl/zh_cn/mapfiles/api-3/12/1","3.12.1"],[1223441094],1.0,null,null,null,null,0,"",null,null,0,"http://khm.googleapis.com/mz?v=125\u0026",null,"https://earthbuilder.google.com","https://earthbuilder.googleapis.com"], loadScriptTime);
  };
  var loadScriptTime = (new Date).getTime();
  getScript("http://maps.gstatic.com/intl/zh_cn/mapfiles/api-3/12/1/main.js");
})();