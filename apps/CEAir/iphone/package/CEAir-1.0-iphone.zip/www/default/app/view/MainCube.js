
/* JavaScript content from app/view/MainCube.js in folder common */
Ext.define('CEAIR.view.MainCube', {
	extend : 'Ext.Panel',
	xtype : 'maincube',
	id : "maincube",
	config : {
		layout : 'vbox',
		items : []
	}
});
