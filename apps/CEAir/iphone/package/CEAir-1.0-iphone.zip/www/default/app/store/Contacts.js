
/* JavaScript content from app/store/Contacts.js in folder common */
/**
 * 联系人
 */
Ext.define('CEAIR.store.Contacts', {
	extend : 'Ext.data.Store',
	config : {
		model : 'CEAIR.model.Contact',
	// data : [ {
	// itemId : "12",
	// name : "aaaasdf",
	// phone : "123123123",
	// email : "aasdfas@sd"
	// } ]
	}
});