
/* JavaScript content from app/view/More/Aboutus.js in folder common */
Ext
		.define(
				'CEAIR.view.More.Aboutus',
				{

					extend : 'Ext.Panel',
					xtype : 'Aboutus',
					id : 'Aboutus',
					config : {
						title : '关于我们',
						layout : {
							type : 'card',
						},
						items : {
							html : "<div style='text-indent:2em;padding:20px;'>中国东方航空股份有限公司是一家总部设在中国上海的国有控股航空公司，于2002年在原中国东方航空集团公司的基础上，兼并中国西北航空公司，联合云南航空公司重组而成。东方航空是中国民航第一家在香港、纽约和上海三地上市的航空公司，1997年2月4日、5日及11月5日，中国东方航空股份有限公司分别在纽约证券交易所（NYSE：CEA）、香港联合交易交所（港交所：0670）和上海证券交易所（上交所：600115）成功挂牌上市。</div>"
						}

					}
				});
