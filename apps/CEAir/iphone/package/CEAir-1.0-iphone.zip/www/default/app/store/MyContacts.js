
/* JavaScript content from app/store/MyContacts.js in folder common */
/**
 * 名片
 */
Ext.define('CEAIR.store.MyContacts', {
	extend : 'Ext.data.Store',
	config : {
		model : 'CEAIR.model.Contact',
	}
});