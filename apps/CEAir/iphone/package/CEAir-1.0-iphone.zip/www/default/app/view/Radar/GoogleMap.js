
/* JavaScript content from app/view/Radar/GoogleMap.js in folder common */
Ext.define('CEAIR.view.Radar.GoogleMap', {
	extend : 'Ext.Container',
	requires : 'Ext.Map',
	xtype : 'googleMapView',
	config : {
		title : "航班地图",
		layout : 'fit',
	},
});