
/* JavaScript content from device/device/Simulator.js in folder common */
/**
 * @private
 */
Ext.define('Ext.device.device.Simulator', {
    extend: 'Ext.device.device.Abstract'
});
